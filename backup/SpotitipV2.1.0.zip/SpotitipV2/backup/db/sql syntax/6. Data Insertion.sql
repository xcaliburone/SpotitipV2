INSERT INTO

INSERT IGNORE INTO

ALTER TABLE `user` ADD INDEX user_name_idx (`name`);

ALTER TABLE `user` DROP INDEX user_name_idx;