<?php
    // if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Ambil data yang dikirim dari form
        // $username = $_POST['username'];
        // $email = $_POST['email'];
        // $password = $_POST['password'];

        // Lakukan koneksi ke database
        // $servername = "127.0.0.1"; // Ganti dengan nama server Anda jika tidak menggunakan localhost
        // $username_db = "root"; // Ganti dengan nama pengguna database Anda
        // $password_db = ""; // Ganti dengan kata sandi database Anda
        // $database = "spotitip"; // Ganti dengan nama database Anda

        // Buat koneksi
        // $conn = new mysqli($servername, $username_db, $password_db, $database);

        // Periksa koneksi
        // if ($conn->connect_error) {
            // die("Koneksi gagal: " . $conn->connect_error);
        // }

        // Query untuk menambahkan user baru ke database
        // $sql = "INSERT INTO user (name, email, password) VALUES ('$username', '$email', '$password')";

        // if ($conn->query($sql) === TRUE) {
            // Jika berhasil ditambahkan, arahkan ke halaman sign in
            // header("Location: SignIn.html");
            // exit;
        // } else {
            // Jika gagal, tampilkan pesan kesalahan
            // echo "Error: " . $sql . "<br>" . $conn->error;
        // }

        // Tutup koneksi
        // $conn->close();
    // }
?>
